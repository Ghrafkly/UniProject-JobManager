create
    definer = root@localhost procedure check_register(IN email varchar(50), IN role varchar(50))
BEGIN

    SELECT * FROM users

                      INNER JOIN roles ON users.role_id = roles.role_id

    WHERE users.email_address = email

      AND role_name = role;

END;

