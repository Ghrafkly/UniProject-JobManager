create
    definer = root@localhost procedure update_lName(IN user int, IN lName varchar(50))
BEGIN

    UPDATE users

    SET user_last_name = lName

    WHERE user_id = user;

END;

