create
    definer = root@localhost procedure add_job_certifications(IN job_id int, IN certification varchar(50))
BEGIN
    INSERT INTO job_certifications (job_id, certification_id)
    VALUES (job_id,
            (SELECT category_id
             FROM categories
             WHERE categories.category_name = certification));
END;

