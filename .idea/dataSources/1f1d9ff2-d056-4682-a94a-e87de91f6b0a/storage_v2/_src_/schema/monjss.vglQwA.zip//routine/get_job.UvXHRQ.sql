create
    definer = root@localhost procedure get_job(IN jobID int)
BEGIN

    SELECT jobs.*, skill_name, company_name

    FROM jobs

             INNER JOIN job_skills ON jobs.job_id = job_skills.job_id

             INNER JOIN skills ON job_skills.skill_id = skills.skill_id

             INNER JOIN company ON jobs.company_id = company.company_id

    WHERE jobs.job_id = jobID;

END;

