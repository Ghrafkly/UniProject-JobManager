create
    definer = root@localhost procedure update_company(IN user int, IN company varchar(50))
BEGIN
    UPDATE users
    SET company_id = (SELECT company_id FROM company WHERE company_name = company)
    WHERE user_id = user;
END;

