create
    definer = root@localhost procedure user_register(IN email varchar(50), IN password varchar(45),
                                                     IN first_name varchar(50), IN last_name varchar(50),
                                                     IN role_name varchar(50))
BEGIN

    INSERT INTO users (email_address, user_password, user_first_name, user_last_name, role_id)

    VALUES (email, password, first_name, last_name,

            (SELECT role_id

             FROM roles

             WHERE roles.role_name = role_name));

END;

