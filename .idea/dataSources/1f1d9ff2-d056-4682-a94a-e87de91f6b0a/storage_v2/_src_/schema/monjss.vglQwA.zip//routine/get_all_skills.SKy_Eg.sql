create
    definer = root@localhost procedure get_all_skills()
BEGIN

    SELECT * FROM skills;

END;

