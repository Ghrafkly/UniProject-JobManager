create
    definer = root@localhost procedure get_roles(IN name varchar(40))
BEGIN
   SELECT * from roles
    WHERE role_name = name;
END;

