create
    definer = root@localhost procedure insert_job_skills(IN job_id int, IN skill_id int)
BEGIN

    INSERT INTO job_skills(job_id, skill_id)

    VALUES (job_id, skill_id);

END;

