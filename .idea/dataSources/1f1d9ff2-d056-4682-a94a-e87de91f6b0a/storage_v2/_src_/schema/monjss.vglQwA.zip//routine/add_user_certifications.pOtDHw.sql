create
    definer = root@localhost procedure add_user_certifications(IN user_id int, IN certification varchar(50))
BEGIN
    INSERT INTO user_certifications (user_id, certification_id)
    VALUES (user_id,
            (SELECT category_id
             FROM categories
             WHERE categories.category_name = certification));
END;

