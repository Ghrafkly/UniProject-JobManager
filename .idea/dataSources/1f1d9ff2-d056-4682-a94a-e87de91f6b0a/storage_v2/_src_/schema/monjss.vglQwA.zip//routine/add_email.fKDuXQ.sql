create
    definer = root@localhost procedure add_email(IN users int)
BEGIN
INSERT INTO users(email_address) 
SELECT email_address
FROM users
INNER JOIN email on users.email_id = email.email_id;
END;

