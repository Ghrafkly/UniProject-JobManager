create
    definer = root@localhost procedure insert_message_type(IN type varchar(50))
BEGIN

    INSERT INTO message_type(message_type)

    VALUES (type);

END;

