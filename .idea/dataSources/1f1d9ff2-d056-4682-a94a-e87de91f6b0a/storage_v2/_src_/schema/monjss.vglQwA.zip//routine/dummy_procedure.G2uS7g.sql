create
    definer = root@localhost procedure dummy_procedure()
BEGIN
    SELECT * FROM roles;
END;

