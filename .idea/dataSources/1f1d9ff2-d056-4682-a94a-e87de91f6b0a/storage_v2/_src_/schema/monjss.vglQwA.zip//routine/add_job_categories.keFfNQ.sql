create
    definer = root@localhost procedure add_job_categories(IN jobID int, IN category varchar(50))
BEGIN

    INSERT INTO job_categories (job_id, category_id)

    VALUES (jobID,

            (SELECT category_id

             FROM categories

             WHERE categories.category_name = category));

END;

