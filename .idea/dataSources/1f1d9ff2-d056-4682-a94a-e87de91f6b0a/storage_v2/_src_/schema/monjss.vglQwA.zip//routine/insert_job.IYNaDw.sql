create
    definer = root@localhost procedure insert_job(IN title varchar(50), IN description varchar(500), IN sal int,
                                                  IN loc varchar(50), IN state_id int, IN comp_id int, IN cert_id int)
BEGIN

    INSERT INTO jobs(job_title, job_description, job_salary, job_location, job_date_created, job_date_app_close, status_id, company_id, certification_id)

    VALUES (title, description, sal, loc, DATE (NOW()), DATE (NOW()) + INTERVAL 1 MONTH, state_id, comp_id, cert_id);

END;

