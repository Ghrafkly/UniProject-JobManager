create
    definer = root@localhost procedure get_user_id(IN email varchar(50), IN role varchar(50))
BEGIN

    SELECT user_id FROM users

                            INNER JOIN roles ON users.role_id = roles.role_id

    WHERE users.email_address = email

      AND role_name = role;

END;

