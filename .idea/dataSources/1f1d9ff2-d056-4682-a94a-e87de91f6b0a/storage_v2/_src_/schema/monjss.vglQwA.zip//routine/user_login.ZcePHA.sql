create
    definer = root@localhost procedure user_login()
BEGIN
    SELECT *
    FROM users
    WHERE users.email_address = email
      AND users.user_password = password
      AND role_id = (SELECT roles.role_id FROM roles WHERE roles.role_name = role_name);
END;

