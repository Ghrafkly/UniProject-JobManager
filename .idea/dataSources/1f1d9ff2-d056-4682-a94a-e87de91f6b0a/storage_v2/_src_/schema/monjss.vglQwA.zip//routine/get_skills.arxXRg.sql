create
    definer = root@localhost procedure get_skills()
BEGIN
    SELECT * from user_skills
    INNER JOIN users ON user_skills.user_id = users.user_id;

END;

