create
    definer = root@localhost procedure update_location(IN user int, IN location varchar(50))
BEGIN

    UPDATE users

    SET user_location = location

    WHERE user_id = user;

END;

