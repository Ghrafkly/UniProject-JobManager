create
    definer = root@localhost procedure get_job_id(IN job_title varchar(50), IN company_name varchar(50))
BEGIN
    SELECT job_id FROM jobs
        INNER JOIN company ON jobs.company_id = company.company_id
    WHERE jobs.job_title = job_title
        AND company.company_name = company_name;
END;

