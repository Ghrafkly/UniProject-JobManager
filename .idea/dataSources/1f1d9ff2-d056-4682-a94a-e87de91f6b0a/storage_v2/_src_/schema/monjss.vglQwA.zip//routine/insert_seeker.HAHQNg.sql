create
    definer = root@localhost procedure insert_seeker(IN email varchar(50), IN roleID int, IN pass varchar(50),
                                                     IN fname varchar(50), IN lname varchar(50), IN cert_id varchar(50))
BEGIN

    INSERT INTO users(email_address, role_id, user_password, user_first_name, user_last_name, certification_id)

    VALUES (email, roleID, pass, fname, lname, cert_id);

END;

