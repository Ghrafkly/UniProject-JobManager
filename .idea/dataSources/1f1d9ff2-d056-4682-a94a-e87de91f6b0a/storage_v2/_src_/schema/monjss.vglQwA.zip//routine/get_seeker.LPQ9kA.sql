create
    definer = root@localhost procedure get_seeker(IN user_id int)
BEGIN

    SELECT * FROM users

                      INNER JOIN roles ON users.role_id = roles.role_id

                      INNER JOIN certification ON users.certification_id = certification.certification_id

    WHERE users.user_id = user_id;

END;

