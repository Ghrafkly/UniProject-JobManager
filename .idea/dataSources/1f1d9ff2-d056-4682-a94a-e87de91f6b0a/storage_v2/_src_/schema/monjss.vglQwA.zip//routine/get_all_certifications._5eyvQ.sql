create
    definer = root@localhost procedure get_all_certifications()
BEGIN

    SELECT * FROM certification;

END;

