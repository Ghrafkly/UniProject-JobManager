create
    definer = root@localhost procedure update_biography(IN user int, IN biography varchar(50))
BEGIN

    UPDATE users

    SET user_biography = biography

    WHERE user_id = user;

END;

