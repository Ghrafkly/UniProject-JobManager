create
    definer = root@localhost procedure user_login(IN email varchar(50), IN password varchar(45),
                                                  IN role_name varchar(45))
BEGIN

    SELECT *

    FROM users

    WHERE users.email_address = email

      AND users.user_password = password

      AND role_id = (SELECT roles.role_id FROM roles WHERE roles.role_name = role_name);

END;

