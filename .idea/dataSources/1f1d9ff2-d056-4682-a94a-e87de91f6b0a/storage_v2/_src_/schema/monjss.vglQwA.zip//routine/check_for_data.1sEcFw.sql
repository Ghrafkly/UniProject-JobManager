create
    definer = root@localhost procedure check_for_data()
BEGIN

    SELECT COUNT(*) FROM users;

END;

