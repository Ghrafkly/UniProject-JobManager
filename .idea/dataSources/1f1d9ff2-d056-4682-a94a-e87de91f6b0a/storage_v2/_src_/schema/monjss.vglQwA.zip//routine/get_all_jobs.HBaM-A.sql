create
    definer = root@localhost procedure get_all_jobs()
BEGIN

    SELECT * FROM jobs

                      INNER JOIN company ON jobs.company_id = company.company_id

                      INNER JOIN state ON jobs.status_id = state.status_id

                      INNer JOIN certification ON jobs.certification_id = certification.certification_id;

END;

