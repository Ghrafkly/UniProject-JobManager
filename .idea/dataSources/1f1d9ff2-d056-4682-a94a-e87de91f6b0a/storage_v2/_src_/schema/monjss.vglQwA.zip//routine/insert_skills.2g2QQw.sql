create
    definer = root@localhost procedure insert_skills(IN skill varchar(50))
BEGIN

    INSERT INTO skills(skill_name)

    VALUES (skill);

END;

