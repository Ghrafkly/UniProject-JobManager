create
    definer = root@localhost procedure add_company(IN name varchar(50))
BEGIN

    INSERT INTO company (company_name)

    VALUES (name);

END;

