create
    definer = root@localhost procedure get_job_skills(IN job_id int)
BEGIN

    SELECT skill_name FROM job_skills

                               INNER JOIN skills ON job_skills.skill_id = skills.skill_id

    WHERE job_skills.job_id = job_id;

END;

