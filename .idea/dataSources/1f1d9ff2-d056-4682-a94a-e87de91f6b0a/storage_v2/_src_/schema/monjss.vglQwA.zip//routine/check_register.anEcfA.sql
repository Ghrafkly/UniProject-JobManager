create
    definer = root@localhost procedure check_register()
BEGIN
    SELECT * FROM users
                      INNER JOIN roles ON users.role_id = roles.role_id
    WHERE users.email_address = email
      AND role_name = role;
END;

