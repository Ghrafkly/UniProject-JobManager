create
    definer = root@localhost procedure get_job_status(IN job_id int)
BEGIN

    SELECT status_type FROM jobs

                                INNER JOIN state ON jobs.status_id = state.status_id

    WHERE jobs.job_id = job_id;

END;

