create
    definer = root@localhost procedure get_job(IN job_id int)
BEGIN
    SELECT * FROM jobs
        INNER JOIN company ON jobs.company_id = company.company_id
    WHERE jobs.job_id = job_id;
END;

