create
    definer = root@localhost procedure get_user_skills(IN user_id int)
BEGIN

    SELECT skill_name FROM user_skills

                               INNER JOIN skills ON user_skills.skill_id = skills.skill_id

    WHERE user_skills.user_id = user_id;

END;

