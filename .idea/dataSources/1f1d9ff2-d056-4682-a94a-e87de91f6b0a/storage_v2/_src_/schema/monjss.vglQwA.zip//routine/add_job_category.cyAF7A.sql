create
    definer = root@localhost procedure add_job_category(IN job_id int, IN category varchar(50))
BEGIN

    INSERT INTO job_categories (job_id, category_id)

    VALUES (job_id,

            (SELECT category_id

             FROM categories

             WHERE categories.category_name = category));

END;

