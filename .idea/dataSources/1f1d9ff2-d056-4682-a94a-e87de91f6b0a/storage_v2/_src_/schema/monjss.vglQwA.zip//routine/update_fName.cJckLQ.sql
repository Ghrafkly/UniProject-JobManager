create
    definer = root@localhost procedure update_fName(IN user int, IN fName varchar(50))
BEGIN

    UPDATE users

    SET user_first_name = fName

    WHERE user_id = user;

END;

