create
    definer = root@localhost procedure check_companies(IN name varchar(50))
BEGIN

    SELECT * FROM company

    WHERE company_name = name;

END;

