create
    definer = root@localhost procedure insert_certification(IN cert varchar(50))
BEGIN

    INSERT INTO certification(certification_name)

    VALUES (cert);

END;

