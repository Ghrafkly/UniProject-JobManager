create
    definer = root@localhost procedure check_login(IN email varchar(50), IN password varchar(45))
BEGIN
SELECT * from users
WHERE 'email' = user_email AND 'password' = user_password;
END;

