create
    definer = root@localhost procedure add_job(IN title varchar(50), IN description varchar(50), IN salary int,
                                               IN location varchar(50), IN status varchar(50), IN companyID int,
                                               IN cert varchar(50))
BEGIN
    INSERT INTO jobs (job_title, job_description, job_salary, job_location, job_date_created, job_date_app_close, status_id, company_id, certification_id)
    VALUES (title, description, salary, location, DATE (NOW()), DATE (NOW()) + INTERVAL 1 MONTH,
            (SELECT status_id
             FROM state
             WHERE status_type = status), companyID,
            (SELECT certification_id
             FROM certification
             WHERE certification_name = cert));
END;

