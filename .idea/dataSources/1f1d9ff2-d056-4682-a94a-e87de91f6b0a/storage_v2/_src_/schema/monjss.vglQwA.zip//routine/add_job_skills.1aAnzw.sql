create
    definer = root@localhost procedure add_job_skills(IN job_id int, IN skill varchar(50))
BEGIN
    INSERT INTO job_skills (job_id, skill_id)
    VALUES (job_id,
            (SELECT skill_id
             FROM skills
             WHERE skills.skill_name = skill));
END;

