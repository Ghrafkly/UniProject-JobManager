create
    definer = root@localhost procedure update_certification(IN userID int, IN cert varchar(50))
BEGIN

    UPDATE users

    SET users.certification_id =

            (SELECT certification_id

             FROM certification

             WHERE certification_name = cert)

    WHERE users.user_id = userID;

END;

