create
    definer = root@localhost procedure insert_recruiter(IN email varchar(50), IN roleID int, IN pass varchar(50),
                                                        IN fname varchar(50), IN lname varchar(50), IN comp_id int)
BEGIN

    INSERT INTO users(email_address, role_id, user_password, user_first_name, user_last_name, company_id)

    VALUES (email, roleID, pass, fname, lname, comp_id);

END;

