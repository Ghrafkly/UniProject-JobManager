create
    definer = root@localhost procedure reset_increments()
BEGIN

    ALTER TABLE user_skills AUTO_INCREMENT = 1;

    ALTER TABLE users AUTO_INCREMENT = 1;

    ALTER TABLE job_categories AUTO_INCREMENT = 1;

    ALTER TABLE job_skills AUTO_INCREMENT = 1;

    ALTER TABLE jobs AUTO_INCREMENT = 1;

    ALTER TABLE categories AUTO_INCREMENT = 1;

    ALTER TABLE certification AUTO_INCREMENT = 1;

    ALTER TABLE company AUTO_INCREMENT = 1;

    ALTER TABLE job_categories AUTO_INCREMENT = 1;

    ALTER TABLE message AUTO_INCREMENT = 1;

    ALTER TABLE message_content AUTO_INCREMENT = 1;

    ALTER TABLE message_type AUTO_INCREMENT = 1;

    ALTER TABLE user_experience AUTO_INCREMENT = 1;

    ALTER TABLE skills AUTO_INCREMENT = 1;

    ALTER TABLE roles AUTO_INCREMENT = 1;

    ALTER TABLE state AUTO_INCREMENT = 1;

    ALTER TABLE status AUTO_INCREMENT = 1;

END;

