create
    definer = root@localhost procedure update_company(IN user int, IN c varchar(50))
BEGIN
    UPDATE users
    SET users.company_id =
        (SELECT company_id
         FROM company
         WHERE company_name = c)
    WHERE user_id = user;
END;

