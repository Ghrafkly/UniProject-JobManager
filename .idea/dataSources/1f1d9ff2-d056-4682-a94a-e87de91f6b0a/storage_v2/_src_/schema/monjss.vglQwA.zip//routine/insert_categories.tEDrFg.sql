create
    definer = root@localhost procedure insert_categories(IN cat varchar(50))
BEGIN
    INSERT INTO categories(category_name)
    VALUES (cat);
END;

