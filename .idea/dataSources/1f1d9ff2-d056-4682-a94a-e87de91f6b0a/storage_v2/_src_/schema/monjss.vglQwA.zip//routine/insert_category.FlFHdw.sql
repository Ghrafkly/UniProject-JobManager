create
    definer = root@localhost procedure insert_category(IN cat varchar(50))
BEGIN

    INSERT INTO categories(category_name)

    VALUES (cat);

END;

