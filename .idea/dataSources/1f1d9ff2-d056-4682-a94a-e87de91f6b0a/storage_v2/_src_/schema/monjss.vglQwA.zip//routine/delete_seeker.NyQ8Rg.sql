create
    definer = root@localhost procedure delete_seeker(IN userID int)
BEGIN

    DELETE FROM user_skills

    WHERE user_id = userID;

    DELETE FROM users

    WHERE user_id = userID;

END;

