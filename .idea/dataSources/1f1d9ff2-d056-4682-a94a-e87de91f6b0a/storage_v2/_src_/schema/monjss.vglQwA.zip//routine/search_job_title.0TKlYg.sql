create
    definer = root@localhost procedure search_job_title(IN title varchar(50))
BEGIN

    SELECT *

    FROM jobs

             INNER JOIN company c on jobs.company_id = c.company_id

             INNER JOIN certification c2 on jobs.certification_id = c2.certification_id

             INNER JOIN state s on jobs.status_id = s.status_id

    WHERE job_title LIKE CONCAT('%', title, '%');

END;

