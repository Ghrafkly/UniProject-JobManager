create
    definer = root@localhost procedure insert_job(IN title varchar(50), IN description varchar(500), IN sal int,
                                                  IN loc varchar(50), IN comp_id int, IN cert_id int, IN state_id int)
BEGIN
    INSERT INTO jobs(job_title, job_description, job_salary, job_location, job_date_created, job_date_app_close, company_id, certification_id, status_id)
    VALUES (title, description, sal, loc, DATE (NOW()), DATE (NOW()) + INTERVAL 1 MONTH, comp_id, cert_id, state_id);
END;

