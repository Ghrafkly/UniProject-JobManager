create
    definer = root@localhost procedure insert_job_category(IN job_id int, IN cat_id int)
BEGIN

    INSERT INTO job_categories(job_id, category_id)

    VALUES (job_id, cat_id);

END;

