create
    definer = root@localhost procedure insert_state(IN type varchar(50))
BEGIN

    INSERT INTO state(status_type)

    VALUES (type);

END;

