create
    definer = root@localhost procedure get_all_categories()
BEGIN

    SELECT * FROM categories;

END;

