create
    definer = root@localhost procedure get_job_categories(IN job_id int)
BEGIN

    SELECT category_name FROM job_categories

                                  INNER JOIN categories ON job_categories.category_id = categories.category_id

    WHERE job_categories.job_id = job_id;

END;

