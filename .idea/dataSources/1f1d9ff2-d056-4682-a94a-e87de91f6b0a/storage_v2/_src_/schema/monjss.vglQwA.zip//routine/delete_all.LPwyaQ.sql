create
    definer = root@localhost procedure delete_all()
BEGIN

    DELETE FROM status;

    DELETE FROM user_skills;

    DELETE FROM users;

    DELETE FROM job_categories;

    DELETE FROM job_skills;

    DELETE FROM jobs;

    DELETE FROM categories;

    DELETE FROM certification;

    DELETE FROM company;

    DELETE FROM job_categories;

    DELETE FROM message;

    DELETE FROM message_content;

    DELETE FROM message_type;

    DELETE FROM user_experience;

    DELETE FROM skills;

    DELETE FROM roles;

    DELETE FROM state;

END;

