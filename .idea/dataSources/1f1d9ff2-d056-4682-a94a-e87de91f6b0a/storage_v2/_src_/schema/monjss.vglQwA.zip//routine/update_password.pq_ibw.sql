create
    definer = root@localhost procedure update_password(IN user int, IN password varchar(50))
BEGIN

    UPDATE users

    SET user_password = password

    WHERE user_id = user;

END;

