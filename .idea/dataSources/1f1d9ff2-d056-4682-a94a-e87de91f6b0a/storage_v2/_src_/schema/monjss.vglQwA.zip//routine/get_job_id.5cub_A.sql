create
    definer = root@localhost procedure get_job_id(IN title varchar(50), IN description varchar(255),
                                                  IN cname varchar(50))
BEGIN
    SELECT job_id FROM jobs
        INNER JOIN company ON jobs.company_id = company.company_id
    WHERE job_title = title
      AND job_description = description
      AND company_name = cname;
END;

