create
    definer = root@localhost procedure apply_for_job(IN userID int, IN jobID int)
BEGIN

    INSERT INTO status (user_id, job_id, status_id)

    VALUES (userID, jobID,

            (SELECT state.status_id

             FROM state

             WHERE state.status_type = 'applied'));

END;

