create
    definer = root@localhost procedure search_job_skills(IN skill varchar(50))
BEGIN

    SELECT *

    FROM jobs

             INNER JOIN company c on jobs.company_id = c.company_id

             INNER JOIN certification c2 on jobs.certification_id = c2.certification_id

             INNER JOIN state s on jobs.status_id = s.status_id

             INNER JOIN job_skills js on jobs.job_id = js.job_id

             INNER JOIN skills s2 on js.skill_id = s2.skill_id

    WHERE s2.skill_name LIKE CONCAT('%', skill, '%');

END;

