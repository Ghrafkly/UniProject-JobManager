create
    definer = root@localhost procedure get_states()
BEGIN

    SELECT status_type FROM state;

END;

