create
    definer = root@localhost procedure has_applied(IN userID int, IN jobID int)
BEGIN

    SELECT *

    FROM status

    WHERE user_id = userID AND job_id = jobID;

END;

