create
    definer = root@localhost procedure add_role(IN users int)
BEGIN
INSERT INTO users(role_name) 
SELECT role_name
FROM users
INNER JOIN roles on users.role_id = roles.role_id;
END;

