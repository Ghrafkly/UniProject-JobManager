create
    definer = root@localhost procedure get_recruiter(IN user_id int)
BEGIN

    SELECT * FROM users

                      INNER JOIN roles ON users.role_id = roles.role_id

                      INNER JOIN company ON users.company_id = company.company_id

    WHERE users.user_id = user_id;

END;

