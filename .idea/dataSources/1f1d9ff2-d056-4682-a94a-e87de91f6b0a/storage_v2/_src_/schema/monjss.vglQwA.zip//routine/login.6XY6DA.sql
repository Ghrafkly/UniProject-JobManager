create
    definer = root@localhost procedure login(IN email varchar(50), IN password varchar(50), IN role varchar(50))
BEGIN
   SELECT *
   FROM users
   INNER JOIN roles
   ON users.role_id = roles.role_id
   WHERE users.user_email = email
      AND users.user_password = password
      AND roles.role_name = role;
END;

