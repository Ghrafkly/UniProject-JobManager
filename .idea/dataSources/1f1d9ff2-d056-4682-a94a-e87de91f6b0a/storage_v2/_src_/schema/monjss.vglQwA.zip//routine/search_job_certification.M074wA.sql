create
    definer = root@localhost procedure search_job_certification(IN cert varchar(50))
BEGIN

    SELECT *

    FROM jobs

             INNER JOIN company c on jobs.company_id = c.company_id

             INNER JOIN certification c2 on jobs.certification_id = c2.certification_id

             INNER JOIN state s on jobs.status_id = s.status_id

    WHERE c2.certification_name LIKE CONCAT(cert, '%');

END;

