create
    definer = root@localhost procedure user_delete(IN email varchar(50), IN role_name varchar(50))
BEGIN
    DELETE FROM users
    WHERE email_address = email
      AND role_id = (SELECT role_id FROM roles WHERE roles.role_name = role_name);
END;

