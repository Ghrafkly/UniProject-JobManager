create
    definer = root@localhost procedure advanced_search4(IN title varchar(50), IN comp varchar(50), IN sal int,
                                                        IN loc varchar(50), IN skill varchar(50))
BEGIN

    SELECT *

    FROM jobs

             INNER JOIN company c on jobs.company_id = c.company_id

             INNER JOIN certification c2 on jobs.certification_id = c2.certification_id

             INNER JOIN state s on jobs.status_id = s.status_id

             INNER JOIN job_skills js on jobs.job_id = js.job_id

             INNER JOIN skills s2 on js.skill_id = s2.skill_id

    WHERE job_title LIKE CONCAT('%', title, '%')

      AND c.company_name LIKE CONCAT('%', comp, '%')

      AND jobs.job_salary >= sal

      AND job_location LIKE CONCAT(loc, '%')

      AND s2.skill_name LIKE CONCAT('%', skill, '%');

END;

