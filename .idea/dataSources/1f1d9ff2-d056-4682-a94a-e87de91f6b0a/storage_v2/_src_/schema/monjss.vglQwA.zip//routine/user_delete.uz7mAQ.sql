create
    definer = root@localhost procedure user_delete(IN users int)
BEGIN
    DELETE FROM users
    WHERE email_address = email
      AND role_id = (SELECT role_id FROM roles WHERE roles.role_name = role_name);
END;

