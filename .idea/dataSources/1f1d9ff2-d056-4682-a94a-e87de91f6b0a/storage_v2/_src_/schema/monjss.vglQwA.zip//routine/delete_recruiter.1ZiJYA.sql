create
    definer = root@localhost procedure delete_recruiter(IN userID int)
BEGIN

    DELETE FROM users

    WHERE user_id = userID;

END;

