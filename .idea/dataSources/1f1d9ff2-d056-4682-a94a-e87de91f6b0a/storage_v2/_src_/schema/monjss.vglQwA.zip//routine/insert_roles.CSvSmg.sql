create
    definer = root@localhost procedure insert_roles(IN role varchar(50))
BEGIN

    INSERT INTO roles(role_name)

    VALUES (role);

END;

