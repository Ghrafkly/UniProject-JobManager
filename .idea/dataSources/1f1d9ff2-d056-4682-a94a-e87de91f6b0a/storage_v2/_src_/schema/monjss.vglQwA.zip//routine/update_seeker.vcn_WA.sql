create
    definer = root@localhost procedure update_seeker(IN userID int, IN fName varchar(50), IN lName varchar(50),
                                                     IN email varchar(50), IN location varchar(50), IN pwd varchar(50),
                                                     IN bio varchar(255), IN cert varchar(50))
BEGIN

    UPDATE users

    SET user_first_name = fName,

        user_first_name = lName,

        email_address = email,

        user_location = location,

        user_password = pwd,

        user_biography = bio,

        certification_id =

            (SELECT certification_id

             FROM certification

             WHERE certification_name = cert)

    WHERE user_id = userID;

END;

