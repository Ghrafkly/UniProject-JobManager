create
    definer = root@localhost procedure cancel_application(IN userID int, IN jobID int)
BEGIN

    DELETE FROM status

    WHERE user_id = userID AND job_id = jobID;

END;

