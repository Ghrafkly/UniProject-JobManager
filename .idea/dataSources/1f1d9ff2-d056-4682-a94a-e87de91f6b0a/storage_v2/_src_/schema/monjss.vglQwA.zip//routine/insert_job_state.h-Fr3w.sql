create
    definer = root@localhost procedure insert_job_state(IN state_id int)
BEGIN
    INSERT INTO state(status_id)
    VALUES (state_id);
END;

