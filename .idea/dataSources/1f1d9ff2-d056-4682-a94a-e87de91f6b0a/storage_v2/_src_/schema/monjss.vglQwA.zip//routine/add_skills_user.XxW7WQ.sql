create
    definer = root@localhost procedure add_skills_user(IN user_id int, IN skill varchar(50))
BEGIN

    INSERT INTO user_skills (user_id, skill_id)

    VALUES (user_id,

            (SELECT skill_id

             FROM skills

             WHERE skills.skill_name = skill));

END;

